CKEDITOR.plugins.add('form', {
    icons: 'form',
    init: function (editor) {
        editor.addCommand('form', new CKEDITOR.dialogCommand('formDialog'));
        editor.ui.addButton('form', {
            label: 'Form',
            command: 'form',
            toolbar: 'insert,8'
        });

        CKEDITOR.dialog.add('formDialog', this.path + 'dialogs/form.js');
    }
});