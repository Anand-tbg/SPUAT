CKEDITOR.plugins.setLang( 'horizontalTab', 'en', {
  dialogTitle: 'Horizontal Tabs',
  invalidTabSetTitle: 'Title field cannot be empty.',
  invalidNumberOfTabs: 'Number of Tabs field cannot be empty.',
  tabBasicLabel: 'Basic Settings',
  infoHtml: '<p>Add Tabs when activity content can easily be segmented into</p>' +
            '<p>separate tabs to allow for more efficient use of space.<p>',
  tabSetTitleLabel: 'Tab Set Title *',
  numberOfTabsLabel: 'Number of Tabs *',
  removeTabLabel: 'Remove a Tab',
  removeTabDefault: 'Choose a Tab to Remove',
  buttonLabel: 'Insert Horizontal Tab',
  contextMenuLabel:'Edit Tabs'
});
