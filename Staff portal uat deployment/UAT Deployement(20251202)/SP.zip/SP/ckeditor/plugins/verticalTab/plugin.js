/**
 * Reference docs for how to build a CKEditor plugin:
 * http://docs.ckeditor.com/#!/guide/plugin_sdk_sample_1
 */


CKEDITOR.plugins.add('verticalTab', {
    lang: 'en,ru',
    requires: 'dialog',
    icons: 'verticalTab',
    init: function( editor ) {
		// Plugin logic goes here...

    // Create the command for the plugin.
    editor.addCommand('verticalTab', new CKEDITOR.dialogCommand('verticalTabDialog', {
      allowedContent: 'div ul li a[role,href,id,aria-*,data-number-of-tabs,data-tab-set-title,data-toggle](bootstrap-tabs, vertical-tabs, clearfix,nav,nav-tabs,tabs-left,tab-link,active,tab-content,vertical-tab-content,tab-pane,tab-pane-content)'
    }));

    // Add the button for the plugin.
    editor.ui.addButton('verticalTab', {
        label: 'Insert Vertical Tab',
      command: 'verticalTab', // The command that was created by addCommand, above.
      toolbar: 'insert,2' // Defines the toolbar group. Can also specify an index for ordering: 'insert,30' or 'insert,100', or 'insert,0'.
    });

	  CKEDITOR.dialog.add('verticalTabDialog', this.path + 'dialogs/verticalTab.js');

		// Context menu support in CKEditor is implemented by the Context Menu plugin.
    // The context menu implementation should be placed inside the init function in the plugin file,
    // following the command and button definitions.
	  // The if check here is a "best practice".
	  // If for some reason the Context Menu plugin will be removed or not available,
	  // the menu registration should not take place (otherwise an exception is thrown).
	  // http://docs.ckeditor.com/#!/guide/plugin_sdk_sample_2

    if ( editor.contextMenu ) {
      editor.addMenuGroup( 'verticalTabGroup' );
      editor.addMenuItem( 'verticalTabItem', {
        label: editor.lang.verticalTab.contextMenuLabel,
        icon: this.path + 'icons/verticalTab.png',
        command: 'verticalTab',
        group: 'verticalTabGroup'
	    });

	    editor.contextMenu.addListener( function(element) {
		    // If an ascendant of the element has the nav-tabs or tab-content class,
		    // enable the context menu (a button with off state for the tab)
		    ascendant = element.getAscendant( function(element) {
          // NOTE: The first part of this condition determinds if we've reached the '#document' for the page.
          // If we've reached the document ascendant, then calling hasClass() will cause an error, breaking the contextMenu.
          // http://docs.ckeditor.com/#!/api/CKEDITOR.dom.document
          return !( element instanceof CKEDITOR.dom.document ) &&
                  ( element.hasClass('tabs-left') || element.hasClass('vertical-tab-content') );
				});
        if ( ascendant ) {
          return { verticalTabItem: CKEDITOR.TRISTATE_OFF };
        }
	    });

		}

		// Register a doubleclick event handler
		// When an element is double-clicked, the verticalTabDialog
		// will be displayed for elements that are descendents part of a tab set.
		editor.on('doubleclick', function (event) {
      var element = event.data.element;

	    // If an ascendant of the element has the nav-tabs or tab-content class,
	    // enable the context menu (a button with off state for the tab)
	    ascendant = element.getAscendant( function(element) {
	    	// QUESTION: How to prevent linkDialog from displaying on doubleclick in a nav-tab?
	    	// In the case of of a[role="tab"], the link dialog is not displayed, but the verticalTabDialog
	    	// is not displayed as preferred.
        // NOTE: The first part of this condition determinds if we've reached the '#document' for the page.
        // If we've reached the document ascendant, then calling hasClass() will cause an error, breaking the contextMenu.
        // http://docs.ckeditor.com/#!/api/CKEDITOR.dom.document
        return !( element instanceof CKEDITOR.dom.document ) &&
                (
                  ( element.name == 'a' && element.attributes.role == 'tab') ||
                  element.hasClass('tabs-left') ||
                  element.hasClass('vertical-tab-content')
                );
			});

			if ( ascendant ) {
        event.data.dialog = 'verticalTabDialog';
      }

    });
	}
});
