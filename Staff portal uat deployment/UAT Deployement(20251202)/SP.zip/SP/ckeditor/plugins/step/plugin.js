CKEDITOR.plugins.add('step', {
    requires: 'widget',

    icons: 'step',
    init: function (editor) {
        editor.widgets.add('step', {

            button: 'Create a Step',
            toolbar: 'insert,6',
            template:
                '<div class="step">'
                    + '<div class="wf-box clearfix">'
                        + '<p class="wf-title">01</p>'
                        + '<div class="wf-content"><h3>Carry out Privacy Needs Assessment(PNA)</h3><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Blanditiis molestias in delectus! Repellat, delectus. Voluptas saepe impedit, vel maxime a accusantium adipisci. Id recusandae illo eaque illum voluptate tempore sunt.</p></div>'
                    + '</div>'
                    + '<div class="arrow-down"></div>'
                + '</div>',
            editables: {
                title: {
                    selector: '.wf-title',
                },
                content: {
                    selector: '.wf-content',
                },
            },

            upcast: function (element) {
                return element.name == 'div' && element.hasClass('step');
            }
        });
    }
});
