CKEDITOR.plugins.add('rightNavigation', {
    requires: 'widget',

    icons: 'rightNavigation',
    init: function (editor) {
        editor.addCommand('rightNavigation', {
            exec: function () {
                var id = Math.random().toString(36).substr(2, 9);
                var selection = editor.getSelection();
                if (selection.getSelectedText().length > 0) {
                    var content = editor.getSelection().getSelectedText();
                    var content1 = content.length <= 35 ? content : content.substring(0, 35) + "...";
                    var convert = '<span id="' + id + '">' + content + '</span>';
                    editor.insertHtml(convert);
                    var navContent = '<li><a data-title="#' + id + '" href="#' + id + '" data-toggle="tooltip" title="' + content + '" class="itemRightNav">' + content1 + '</a></li>';
                    var buttonShowHide = jQuery(editor.document.getById('sidebarCollapseInline'));
                    var navigation = jQuery(editor.document.getById('rightNavigation-page'));
                    //create element
                    var buttonShowHideAppend = document.createElement("input");
                    buttonShowHideAppend.id="sidebarCollapseInline";
                    buttonShowHideAppend.type="button";
                    buttonShowHideAppend.value = ">";
                    var ulAppend = document.createElement("ul");
                    ulAppend.id = "rightNavigation-page";
                    ulAppend.className = "rightNavigation-page";

                    if (navigation.length != 0 && buttonShowHide.length == 0) {
                        navigation[0].appendHtml(navContent);
                        editor.document.$.body.appendChild(buttonShowHideAppend);
                    } else if (navigation.length == 0 && buttonShowHide.length == 0) {
                        editor.document.$.body.appendChild(ulAppend);
                        var navigation = jQuery(editor.document.getById('rightNavigation-page'));
                        navigation[0].appendHtml(navContent);
                        editor.document.$.body.appendChild(buttonShowHideAppend);
                    }
                    else if (navigation.length == 0 && buttonShowHide.length != 0) {
                        editor.document.$.body.appendChild(ulAppend);
                        var navigation = jQuery(editor.document.getById('rightNavigation-page'));
                        navigation[0].appendHtml(navContent);
                    }
                    if (navigation.length != 0 && buttonShowHide.length != 0)
                    {
                        navigation[0].appendHtml(navContent);
                    }
                    var btnShowHide = editor.document.getById("sidebarCollapseInline");
                    var rightNav = editor.document.getById("rightNavigation-page");
                    btnShowHide.$.onclick = function () {
                        var cls = jQuery(rightNav).attr("class");
                        if (cls.indexOf("hide") != -1) {
                            jQuery(btnShowHide).attr("value", ">");
                            jQuery(rightNav).attr("class", "rightNavigation-page");
                        }
                        else {
                            jQuery(btnShowHide).attr("value", "<");
                            jQuery(rightNav).attr("class", "rightNavigation-page hide")
                        }
                    }
                } //if
            }
        });
        editor.ui.addButton('rightNavigation', {
            label: 'Create a Right Navigation',
            toolbar: 'insert,5',
            command: 'rightNavigation',
            icon: 'rightNavigation',
        });
    }
});
