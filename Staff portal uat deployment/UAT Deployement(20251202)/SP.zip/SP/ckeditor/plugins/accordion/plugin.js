CKEDITOR.plugins.add('accordion', {
    requires: 'widget',

    icons: 'accordion',

    init: function (editor) {
        editor.addCommand('insertAccordion', {
            exec: function (editor) {
                var id = Math.random().toString(36).substr(2, 9);
                editor.insertHtml('<div class="custom-collapse">' +
                    '<div class="heading" contenteditable="false">' +
                    '<div class="bt-collapse" aria-expanded="false" data-toggle="collapse" contenteditable="false" data-target="#accordion_' + id + '">+</div>' +
                    '<div class="title-collapse" contenteditable="true">Title</div>' +
                    '</div>' +
                    '<div id="accordion_' + id + '" class="collapse collapse-content" contenteditable="false" style="height: auto !important;">' +
                    '<div class="collapse-text" contenteditable="true">Lorem ipsum dolor sit amet, consectetur adipisicing elit,' +
                    'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,' +
                    'quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.' +
                    'Lorem ipsum dolor sit amet, consectetur adipisicing elit,' +
                    '</div>' +
                    '</div>' +
                    '</div></br>');

                Expande(id);
            }
        });
        editor.ui.addButton('Accordion', {
            label: 'Create Accordion',
            command: 'insertAccordion',
            toolbar: 'insert,4'
        });

    }
});

function Expande(id) {
    var iframe = jQuery("div[id*='txtBody'] iframe");
    var Heading = jQuery(iframe).contents().find("div[data-target*='#accordion_" + id + "']");
    jQuery(Heading).click(function (e) {
        var stt = jQuery(this).attr("aria-expanded");
        if (stt == "true") {
            jQuery(this).html("+");
            jQuery(this).removeClass("custome-collapse-open");
        }
        else {
            jQuery(this).html("-");
            jQuery(this).addClass("custome-collapse-open");
        }
    });
}