CKEDITOR.plugins.setLang( 'newsletter', 'en', {
  dialogTitle: 'Newsletter',
  invalidTabSetTitle: 'Title field cannot be empty.',
  invalidIssueNo: 'Issue No cannot be empty.',
  invalidNumberOfTabs: 'No. of Highlight field cannot be empty.',
  invalidIssueDate: 'Issue Date field cannot be empty.',
  tabBasicLabel: 'Basic Settings',
  infoHtml: '<p>Add Newsletter to get the layout for Spicy<p>',
  tabSetTitleLabel: 'Tab Set Title *',
  tabIssueNoLabel: 'Issue No *',
  tabIssueDateLabel: 'Issue Date *',
  numberOfTabsLabel: 'No. of Highlight *',
  removeTabLabel: 'Remove a Tab',
  removeTabDefault: 'Choose a Tab to Remove',
  buttonLabel: 'Insert Newsletter',
  contextMenuLabel:'Edit Tabs'
});
