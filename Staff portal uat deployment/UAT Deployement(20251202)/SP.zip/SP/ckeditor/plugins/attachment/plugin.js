CKEDITOR.plugins.add('attachment', {
    icons: 'attachment',
    init: function (editor) {
        editor.addCommand('attachment', new CKEDITOR.dialogCommand('attachmentDialog'));
        editor.ui.addButton('attachment', {
            label: 'Attachment',
            command: 'attachment',
            toolbar: 'insert,9'
        });

        CKEDITOR.dialog.add('attachmentDialog', this.path + 'dialogs/attachment.js');
    }
});