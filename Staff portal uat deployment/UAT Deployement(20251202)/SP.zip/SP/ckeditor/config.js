/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

function msieversion() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0) {
        // If Internet Explorer, return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
    } // If another browser, return 0
    else {
        return -1;
    }
    return false;
}

CKEDITOR.on("instanceReady", function (ev) {
    // var jqScript = document.createElement("script");
    // var popper = document.createElement("script");
    // var bsScript = document.createElement("script");

    // // jqScript.src = "/sites/staffportal-dev/SiteAssets/SP/ckeditor/jquery.min.js";
    // popper.src = "/sites/staffportal-dev/SiteAssets/SP/js/popper.min.js";
    // //jqScriptMigrate = "/_layouts/15/SP.SPS/sps-scripts/jquery/jquery-migrate.min.js";
    // bsScript.src = "/sites/staffportal-dev/SiteAssets/SP/js/bootstrap.min.js";

    // var editorHead = ev.editor.document.$.head;
    // // editorHead.appendChild(jqScript);
    // editorHead.appendChild(popper);

    // if (msieversion() == -1) {
    //     popper.onload = function () {
    //         editorHead.appendChild(bsScript);
    //     };
    // } else {
    //     editorHead.appendChild(bsScript);

    // }
    // editorHead.appendChild(bsScript);
});

CKEDITOR.editorConfig = function (config) {
    // Define changes to default configuration here. For example:
    // config.language = 'fr';
    // config.uiColor = '#AADC6E';
    config.contentsCss = ['/sites/staffportal-dev/SiteAssets/SP/css/bootstrap.min.css', '/sites/staffportal-dev/SiteAssets/SP/ckeditor/sps-inlineCKeditor.css?v=62.0', ''];
    //config.scayt_autoStartup = true,
    config.extraPlugins = 'step,lastStep, accordion, verticalTab, horizontalTab, rightNavigation, newsletter,image2,form,attachment';
    config.removePlugins = 'image,scayt,wsc,save,newpage,exportpdf,print,templates,showblocks,smiley,pastetext,pastefromword';
    config.disableNativeSpellChecker = false;
    // Set the most common block elements.
    config.format_tags = 'p;h1;h2;h3;h4;pre;div';
    config.fillEmptyBlocks = false;
    config.tabSpaces = 0;
    // Simplify the dialog windows.
    config.removeDialogTabs = 'image:advanced;link:advanced';
    config.allowedContent = true;
    config.extraAllowedContent = 'div(*)';
    config.extraAllowedContent = 'div(col-md-*,container-fluid,row, col-xs-*, col-lg-*,col-sm-*)';
    config.enterMode = CKEDITOR.ENTER_BR;
    config.height = '500px';
    config.baseFloatZIndex = 1000;
    config.toolbarGroups = [
		{ name: 'tools' },
		{ name: 'document', groups: ['mode', 'document', 'doctools'] },
        { name: 'insert' },
		{ name: 'basicstyles' },
        { name: 'colors' },
        { name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align'] },
		{ name: 'styles' },
        { name: 'clipboard', groups: ['clipboard', 'undo'] },
        //{ name: 'editing', groups: ['spellchecker'] },
        { name: 'links' },
        { name: 'others' }
    ];
    config.removeButtons = 'Preview,Flash,CreateDiv';
    CKEDITOR.dtd.$removeEmpty.span = false;
    CKEDITOR.dtd.$removeEmpty.i = false;
    config.defaultLanguage = 'en';
    config.disableObjectResizing = true;
    config.mediaEmbed = {
        previewsInData: true
    };
};
